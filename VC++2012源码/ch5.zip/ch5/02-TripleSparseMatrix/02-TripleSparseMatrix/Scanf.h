#pragma once
#ifndef SCANF_H
#define SCANF_H


#include <stdio.h>
#include <string.h>
#include <stdarg.h>				//�ṩ��va_list��va_start��va_arg��va_end	
#include <ctype.h> 				//�ṩisprintԭ�� 

int Scanf(FILE *fp, char *format, ...);




#endif